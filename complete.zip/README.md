# Cafeteria (MERN, Vite + Express) — Deploy Ready (No Tailwind)

This is a complete cafeteria management app with:
- Users can order single items or cart; gets a **token** (MongoDB `_id`) in a popup with **copy**.
- Admin can add/delete items.
- Search by **name or tag**.
- Auth with roles (user/admin).
- Clean **CSS** only (no Tailwind).

## Folder Structure
```
cafeteria/
├─ server/    # Express + Mongo + JWT
└─ client/    # React + Vite
```

## Run Locally (Compass)
1. Backend
```
cd server
cp .env.example .env
npm install
npm run dev
```
2. Frontend
```
cd ../client
npm install
npm run dev
```
Open http://localhost:5173

## MongoDB Atlas
Set `MONGODB_URI` in `server/.env` to your Atlas string.

## Deploy
### Backend → Render
- Root: `server/`
- Build: `npm install`
- Start: `npm start`
- Environment variables:
  - `MONGODB_URI`
  - `JWT_SECRET`
  - `CORS_ORIGIN` = `http://localhost:5173,https://cafeteria-deployed.vercel.app`

### Frontend → Vercel
- Root: `client/`
- Env:
  - `VITE_API_URL` = `https://<your-render-service>.onrender.com`

## Notes
- Having two `node_modules` (one in `server/` and one in `client/`) is normal in MERN.
- Make an admin by editing your user document `role: "admin"` in MongoDB.
