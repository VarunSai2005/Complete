export const ROLES = {
  USER: 'user',
  ADMIN: 'admin',
}
